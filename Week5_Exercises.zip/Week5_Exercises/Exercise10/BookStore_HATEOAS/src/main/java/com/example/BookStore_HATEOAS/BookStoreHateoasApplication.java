package com.example.BookStore_HATEOAS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStoreHateoasApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreHateoasApplication.class, args);
	}

}
